<?php
class ErrorCode
{
	static public $OK = 0;
	static public $IllegalAesKey = -41001;
	static public $IllegalIv = -41002;
	static public $IllegalBuffer = -41003;
	static public $DecodeBase64Error = -41004;
}


?>
